---
name: "youtube-automation-skill"
description: "Write short video reel scripts for my youtube automation\nUse this skill only if I asked about writing a reel script because I might prompt other topics in the ai typebox. Make a 45 second script for short videos for the brand. I will just tell what is the focused topic of the video because I am still figuring out what is the best video niche is for me ."
---

## Script format 
The output of the script is exactly this structure. 

Hook is 0 to 4 seconds of the video, a punchy open line that intrigues the audience. 

Problem (4 to 20 seconds)
Tell about the problem like it is a painpoint of the audience. Make them feel that the problem shown in the video is also their problem 

Solution(Propose a solution: 21 seconds to 35 seconds of the video)
Introduce a tip or an advice as an answer, 2 to 3 sentences 

CTA (Call to action: 36 to 45 seconds)
This may trigger the audience to subscribe for more tips and advice. 